#include "hasharray.h"

/*template<class dataType>
HashArray::HashArray(int array_size)
{
    currentSize = 0;
    arraySize = array_size;
    dataOffset = 0;
    array = new list<dataType *>[arraySize];
}

template<class dataType>
void HashArray::push(dataType * data){
    if (!dataOffset){
        dataOffset = data;
    }
    array[data - dataOffset].push(data);
    currentSize++;
}

template<class dataType>
void HashArray::remove(dataType *data){
    array[data - dataOffset].remove(data);
}

HashArray::~HashArray()
{

}*/

