#include "timesensesequenceam.h"

TimeSenseSequenceAM::TimeSenseSequenceAM()
{

}

TimeSenseSequenceAM::~TimeSenseSequenceAM()
{

}

