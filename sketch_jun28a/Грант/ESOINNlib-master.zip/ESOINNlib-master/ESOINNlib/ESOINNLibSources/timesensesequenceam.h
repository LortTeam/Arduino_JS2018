#ifndef TIMESENSESEQUENCEAM_H
#define TIMESENSESEQUENCEAM_H


class TimeSenseSequenceAM
{
public:
    TimeSenseSequenceAM();
    ~TimeSenseSequenceAM();
};

#endif // TIMESENSESEQUENCEAM_H
